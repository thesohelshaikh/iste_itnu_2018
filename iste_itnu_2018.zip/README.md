# iste_itnu_2018
Website for ISTE club of Nirma University for 2018

![iste Logo](/img/iste-logo-dark.png)

## About the club
ISTE Students’ Chapter is a premier club at the Institute Of Technology, Nirma University. It is the only techno-cultural social club of that organizes technical and non- technical events at National, State ,University and Institute level round the year addressing the technical and creative side of the TECHNOCRATS.ISTE, ISTE-ITNU is that umbrella organisation which shelters, cares for and motivates the students to use their creative minds and their boundless imagination in the best possible way. The young, energetic, enthusiastic ISTEans have always made their mark wherever they set their foot. And the result is ISTE-ITNU has been awarded the "BEST STUDENTS' CHAPTER AWARD" Six times.

Students from ISTE-ITNU have proved their versatility distinctively in every genre, right from the technical arena to the cultural domain. Furthermore, they fulfil   their duties as responsible citizens by doing their bit in eradicating and breaking free from the social shackles prevalent in our society through their social endeavour ' KOSHISH'.

ISTE-ITNU set a new record of quality events this year, taking the bar even higher than previous years. Merging innovation with popularity, the club has broken new grounds of achievements. Right from enjoying so much of popularity on the campus in terms of attracting new blood every year to the widespread fame gained in terms of plethora of novelty in both – its signature events and newly introduced ones, ISTE-ITNU has all of it! The boldness of the club is also apparent in the challenges it has taken into hands. ISTEans (ITNU) have successfully organized 2 national level tech fests (IFEST and NUTECH of which Chapter was part of The NUTECH’14 Team) apart from its social activities. Another feather in the cap of ISTE was the successful and satisfactory completion of IFEST 13’ with around 4000 participants from all over the place thronging the campus.

Also, ISTE was the pioneer club, which organized the 1st ever technical night in Gujarat in the form of a wonderful 3-D Mapping show!!

ISTE has successfully left behind an even stronger legacy for the others to carry forward and the journey of college life becomes even more stupendous when undertaken with ISTE!!
